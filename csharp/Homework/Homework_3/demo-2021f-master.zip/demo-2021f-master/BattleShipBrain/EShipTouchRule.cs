namespace BattleShipBrain
{
    public enum EShipTouchRule
    {
        NoTouch,
        CornerTouch,
        SideTouch
    }
}