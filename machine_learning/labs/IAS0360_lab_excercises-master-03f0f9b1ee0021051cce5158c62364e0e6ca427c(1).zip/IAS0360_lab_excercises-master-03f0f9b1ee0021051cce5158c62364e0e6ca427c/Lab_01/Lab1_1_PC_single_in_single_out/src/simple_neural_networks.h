#ifndef __SIMPLE_NEURAL_NETWORK
#define __SIMPLE_NEURAL_NETWORK

#include <stdint.h>

int32_t single_in_single_out_nn(int32_t input, int32_t weight);
#endif
