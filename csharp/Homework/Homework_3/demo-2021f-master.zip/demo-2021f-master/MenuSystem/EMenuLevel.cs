namespace MenuSystem
{
    public enum EMenuLevel
    {
        Root,
        First,
        SecondOrMore
    }
}