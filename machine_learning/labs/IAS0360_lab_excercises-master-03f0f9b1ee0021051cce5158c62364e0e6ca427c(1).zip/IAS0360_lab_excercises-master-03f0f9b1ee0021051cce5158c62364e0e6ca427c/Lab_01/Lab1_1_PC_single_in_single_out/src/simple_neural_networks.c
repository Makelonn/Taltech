#include "simple_neural_networks.h"

int32_t single_in_single_out_nn(int32_t input, int32_t weight) {
   	// TODO: Return the result of multiplication of input and its weight.
	return 0;
}
